package com.example.pierre.jdrrestclient;

/**
 * Created by pierre on 05/04/2016.
 */
public abstract class Arme{
    private String nom_arme;
    private String type;
    private int degat;

    public Arme() {
    }

    public Arme(String nom, String type, int degat) {
        this.nom_arme = nom;
        this.type = type;
        this.degat = degat;
    }

    public int attaque(Creature at, Creature def) {
        int Attaque = (int) (Math.random() * 20 );
        System.out.println(at.getNom() + " attaque "+ def.getNom()+ " fai un jet de toucher de "+Attaque);
        if (Attaque+at.getCA() >def.getCD()){
            System.out.println(Attaque + " + " + at.getCA() + " est superieur a "+def.getCD()+" donc l'attaque touche");
            def.setPV(def.getPV()-(this.degat+(at.getF()/10)));
            System.out.println(" et inflige "+(this.degat+(at.getF()/10))+ " a "+def.getNom()+ " il lui reste donc "+def.getPV()+" PV");

        }else{
            System.out.println(Attaque + " + " + at.getCA() + " est inferieur a "+def.getCD() +" donc l'attaque rate la cible");
        }




        return 0;
    }


    public String getNom_arme() {
        return nom_arme;
    }

    public void setNom_arme(String nom_arme) {
        this.nom_arme = nom_arme;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getDegat() {
        return degat;
    }

    public void setDegat(int degat) {
        this.degat = degat;
    }
}
