package com.example.pierre.jdrrestclient;

/**
 * Created by pierre on 31/03/2016.
 */
public class Epée extends Arme {
    public Epée(String nom, String type, int degat) {
        super(nom,type,degat);
    }

    public Epée() {
    }

    public int attaque(Creature at, Creature def) {
        int Attaque = (int) (Math.random() * 20 );
        Attaque=Attaque+1;
        System.out.println(at.getNom() + " attaque "+ def.getNom()+ " fai un jet de toucher de "+Attaque);
        if (Attaque+at.getCA() >def.getCD()){
            int deg=(int) (Math.random() * 10 );
            if (deg==10){
                deg=deg+5;
            }
            System.out.println(Attaque + " + " + at.getCA() + " est superieur a "+def.getCD()+" donc l'attaque touche");
            def.setPV(def.getPV()-(this.getDegat()+(at.getF()/10)+deg));
            System.out.println(" et inflige "+(this.getDegat()+(at.getF()/10)+deg)+ " a "+def.getNom()+ " il lui reste donc "+def.getPV()+" PV");

        }else{
            System.out.println(Attaque + " + " + at.getCA() + " est inferieur a "+def.getCD() +" donc l'attaque rate la cible");
        }




        return 0;
    }


}
