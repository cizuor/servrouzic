package com.example.pierre.jdrrestclient;

/**
 * Created by pierre on 05/04/2016.
 */
public class Creature {
    private String nom;
    private int Prix;
    private int CA;
    private int CD;
    private int CC;
    private int CT;
    private int Ag;
    private int F;
    private int E;
    private int FM;
    private int At;
    private int Int;
    private int Mag;
    private int P;
    private int Soc;
    private Arme arme;
    private int PV;


    public Creature(String nom, int prix, int CA, int CD, int CC, int CT, int ag, int f, int e, int FM, int at, int anInt, int mag, int p, int soc, Arme arme, int PV) {
        this.nom = nom;
        Prix = prix;
        this.CA = CA;
        this.CD = CD;
        this.CC = CC;
        this.CT = CT;
        Ag = ag;
        F = f;
        E = e;
        this.FM = FM;
        At = at;
        Int = anInt;
        Mag = mag;
        P = p;
        Soc = soc;
        this.arme = arme;
        this.PV = PV;
    }

    public Creature(String nom) {
        this.nom = nom;
        Prix = 25;
        this.CA = 2;
        this.CD = 12;
        this.CC = 20;
        this.CT = 20;
        Ag = 20;
        F = 20;
        E = 20;
        this.FM = 20;
        At = 1;
        Int = 20;
        Mag = 0;
        P = 20;
        Soc = 20;
        this.arme = new Epée("épée","perforant",0);
        this.PV = PV;
    }

    public Creature() {
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getPrix() {
        return Prix;
    }

    public void setPrix(int prix) {
        Prix = prix;
    }

    public int getCA() {
        return CA;
    }

    public void setCA(int CA) {
        this.CA = CA;
    }

    public int getCD() {
        return CD;
    }

    public void setCD(int CD) {
        this.CD = CD;
    }

    public int getCC() {
        return CC;
    }

    public void setCC(int CC) {
        this.CC = CC;
    }

    public int getCT() {
        return CT;
    }

    public void setCT(int CT) {
        this.CT = CT;
    }

    public int getAg() {
        return Ag;
    }

    public void setAg(int ag) {
        Ag = ag;
    }

    public int getF() {
        return F;
    }

    public void setF(int f) {
        F = f;
    }

    public int getE() {
        return E;
    }

    public void setE(int e) {
        E = e;
    }

    public int getFM() {
        return FM;
    }

    public void setFM(int FM) {
        this.FM = FM;
    }

    public int getAt() {
        return At;
    }

    public void setAt(int at) {
        At = at;
    }

    public int getInt() {
        return Int;
    }

    public void setInt(int anInt) {
        Int = anInt;
    }

    public int getMag() {
        return Mag;
    }

    public void setMag(int mag) {
        Mag = mag;
    }

    public int getP() {
        return P;
    }

    public void setP(int p) {
        P = p;
    }

    public int getSoc() {
        return Soc;
    }

    public void setSoc(int soc) {
        Soc = soc;
    }

    public Arme getArme() {
        return arme;
    }

    public void setArme(Arme arme) {
        this.arme = arme;
    }

    public int getPV() {
        return PV;
    }

    public void setPV(int PV) {
        this.PV = PV;
    }


    public void mort (){

    }

    @Override
    public String toString() {
        return "Creature{" +
                "nom='" + nom + '\'' +
                ", Prix=" + Prix +
                ", CA=" + CA +
                ", CD=" + CD +
                ", CC=" + CC +
                ", CT=" + CT +
                ", Ag=" + Ag +
                ", F=" + F +
                ", E=" + E +
                ", FM=" + FM +
                ", At=" + At +
                ", Int=" + Int +
                ", Mag=" + Mag +
                ", P=" + P +
                ", Soc=" + Soc +
                ", arme=" + arme +
                ", PV=" + PV +
                '}';
    }


    public String name() {
        return null;
    }

    /*public void Attaque (Creature c2){
        int Attaque = (int) (Math.random() * 20 );
        System.out.println(this.nom + " attaque "+ c2.getNom()+ " fai un jet de toucher de "+Attaque);
        if (Attaque+this.CA >c2.CD){
            System.out.println(Attaque + " + " + this.getCA() + " est superieur a "+c2.getCD()+" donc l'attaque touche");
            c2.setPV(c2.getPV()-this.Degat);
            System.out.println(" et inflige "+this.getDegat()+ " a "+c2.getNom()+ " il lui reste donc "+c2.getPV()+" PV");

        }else{
            System.out.println(Attaque + " + " + this.getCA() + " est inferieur a "+c2.getCD() +" donc l'attaque rate la cible");
        }

    }*/


    public void Attaque (Creature c2){
        arme.attaque(this,c2);
    }




}

