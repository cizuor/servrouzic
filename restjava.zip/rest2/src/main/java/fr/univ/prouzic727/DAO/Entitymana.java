package fr.univ.prouzic727.DAO;

import javax.persistence.*;
import java.sql.SQLException;

/**
 * Created by pierre on 12/03/2016.
 */
public class Entitymana<T extends Entity> implements CRUD<T>{

    private EntityManagerFactory emf;
    private EntityManager em;

    public Entitymana() {
        emf = Persistence.createEntityManagerFactory("testpostgresqllocal");
        em = emf.createEntityManager();
    }




    public T create(T t){

        EntityTransaction transac = em.getTransaction();
        transac.begin();
        em.persist(t);
        transac.commit();

        return t;
    }

    public T find(Class type, Object id) {
        EntityTransaction transac = em.getTransaction();
        transac.begin();
        T t = (T) em.find(type, id);
        transac.commit();
        return t;

    }

    public T update(T t) {
        return null;
    }


    public void delete(Class type, Object id) {
        EntityTransaction entityTransaction = em.getTransaction();
        T t = (T) em.find(type,id);
        entityTransaction.begin();
        em.remove(t);
        entityTransaction.commit();


    }
}
