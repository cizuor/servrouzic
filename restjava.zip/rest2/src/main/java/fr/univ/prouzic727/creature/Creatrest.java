package fr.univ.prouzic727.creature;

import com.google.gson.Gson;
import fr.univ.prouzic727.DAO.Entitymana;
import fr.univ.prouzic727.creature.Creature;
import org.json.simple.parser.JSONParser;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by pierre on 12/03/2016.
 */


@Path("/Creat")
public class Creatrest {


    static Entitymana entitymana = new Entitymana();

    Creature modelcreat;
    private static List<Creature> creatList = new ArrayList<Creature>();

    @GET
    @Produces("text/plain")
    public String getIt() {
        return "Got it!";
    }



    @GET
    @Path("/test")
    public String test() {
        return "test";
    }


    @GET
    @Path("testput")//http://localhost:9998/Creat/testput/?test=20
    @Produces("text/plain")
    public String testput(@QueryParam("test") int test){
        return "test it! "+ test;
    }
    /*@GET
    @Path("/putNew")//http://localhost:9998/Creat/putNew/?nom=gob&Prix=3&CA=3&CD=12&Ag=40&Degat=3&PV=20
    public String nouv(@QueryParam("nom") String nom,@QueryParam("Prix") int prix,@QueryParam("CA") int CA,@QueryParam("CD") int CD,@QueryParam("Ag") int Ag,@QueryParam("Degat") int degat,@QueryParam("PV") int PV ) {
        Creature creat = new Creature(nom,prix,CA,CD,Ag,degat,PV);
        entitymana.create(creat);
        creatList.add(creat);
        return "nom = "+creat.getNom()+ " CA = "+creat.getCA();
    }*/
    @GET
    @Path("/putNew")//http://localhost:9998/Creat/putNew/?nom=gob
    public String nouv(@QueryParam("nom") String nom  ) {
        int test =0;
        for (int i = 0; i <creatList.size() ; i++) {
            if (creatList.get(i).getNom().equals(nom)){
                test=1;
                Gson gson = new Gson();
                String json = gson.toJson(creatList.get(i));
                return json;

            }
        }
        if(test==0) {
            Creature creat=null;
            creat= (Creature) entitymana.find(Creature.class,nom);
            if(creat !=null){
                test=1;
            }

        }
        if (test ==0){
            Creature creat = new Creature(nom);
            entitymana.create(creat);
            creatList.add(creat);
            Gson gson = new Gson();
            String json = gson.toJson(creat);
            //return "nom = " + creat.getNom() + " CA = " + creat.getCA();
            return json;
        }
        return "erreur";
    }



    @GET
    @Path("/changepv")//http://localhost:9998/Creat/changepv/?nom=gob&PV=3
    public String changepv(@QueryParam("nom") String nom, @QueryParam("PV") int PV ) {
        int test =0;
        for (int i = 0; i <creatList.size() ; i++) {
            if (creatList.get(i).getNom().equals(nom)){
                test=1;
                creatList.get(i).setPV(PV);
                entitymana.delete(Creature.class,creatList.get(i).getNom()); // URGENT faire le update
                entitymana.create(creatList.get(i));                        //  changer ces ligne
                Gson gson = new Gson();
                String json = gson.toJson(creatList.get(i));
                return json;

            }
        }
        if(test==0) {
            Creature creat=null;
            creat= (Creature) entitymana.find(Creature.class,nom);
            if(creat !=null){
                creat.setPV(PV);
                entitymana.delete(Creature.class,creat.getNom());// URGENT faire le update
                entitymana.create(creat);                        //  changer ces ligne
                Gson gson = new Gson();
                String json = gson.toJson(creat);
                return json;
            }

        }
        return "erreur";
    }








    @GET
    @Path("/getbyNom")//http://localhost:9998/Creat/getbyNom/?nom=tic
    public  String getnom(@QueryParam("nom") String nom){
        Creature creat=null;
        creat= (Creature) entitymana.find(Creature.class,nom);


        Gson gson = new Gson();
        String json = gson.toJson(creat);
        return json;
    }





}
