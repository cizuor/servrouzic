package fr.univ.prouzic727.arme;

import fr.univ.prouzic727.creature.Creature;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Created by pierre on 31/03/2016.
 */

@Entity
public abstract class Arme implements Entity {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private int id;
    private String nom_arme;
    private String type;
    private int degat;

    public Arme() {
    }

    public Arme(String nom, String type, int degat) {
        this.nom_arme = nom;
        this.type = type;
        this.degat = degat;
    }

    public int attaque(Creature at, Creature def) {
        int Attaque = (int) (Math.random() * 20 );
        System.out.println(at.getNom() + " attaque "+ def.getNom()+ " fai un jet de toucher de "+Attaque);
        if (Attaque+at.getCA() >def.getCD()){
            System.out.println(Attaque + " + " + at.getCA() + " est superieur a "+def.getCD()+" donc l'attaque touche");
            def.setPV(def.getPV()-(this.degat+(at.getF()/10)));
            System.out.println(" et inflige "+(this.degat+(at.getF()/10))+ " a "+def.getNom()+ " il lui reste donc "+def.getPV()+" PV");

        }else{
            System.out.println(Attaque + " + " + at.getCA() + " est inferieur a "+def.getCD() +" donc l'attaque rate la cible");
        }




        return 0;
    }


    public String getNom_arme() {
        return nom_arme;
    }

    public void setNom_arme(String nom_arme) {
        this.nom_arme = nom_arme;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getDegat() {
        return degat;
    }

    public void setDegat(int degat) {
        this.degat = degat;
    }
}
