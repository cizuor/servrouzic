package fr.univ.prouzic727.DAO;

import javax.persistence.Entity;

/**
 * Created by pierre on 14/03/2016.
 */
public interface CRUD<T extends Entity>{
    public T create(T t);
    public T find(Class type, Object id);
    public T update(T t);
    public void delete(Class type, Object id);


}
