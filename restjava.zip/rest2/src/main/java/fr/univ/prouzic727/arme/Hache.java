package fr.univ.prouzic727.arme;

import fr.univ.prouzic727.creature.Creature;

import javax.persistence.Entity;
import java.lang.annotation.Annotation;

/**
 * Created by pierre on 31/03/2016.
 */
@Entity
public class Hache extends Arme {

    public Hache(String nom, String type, int degat) {
        super(nom,type,degat);
    }

    public Hache() {
    }

    public int attaque(Creature at, Creature def) {
        int Attaque = (int) (Math.random() * 20 );
        Attaque=Attaque;
        System.out.println(at.getNom() + " attaque "+ def.getNom()+ " fai un jet de toucher de "+Attaque);
        if (Attaque+at.getCA() >def.getCD()){
            int deg=(int) (Math.random() * 10 );
            if (deg==10){
                deg=deg+8;
            }
            System.out.println(Attaque + " + " + at.getCA() + " est superieur a "+def.getCD()+" donc l'attaque touche");
            def.setPV(def.getPV()-(this.getDegat()+(at.getF()/10)+deg));
            System.out.println(" et inflige "+(this.getDegat()+(at.getF()/10)+deg)+ " a "+def.getNom()+ " il lui reste donc "+def.getPV()+" PV");
        }else{
            System.out.println(Attaque + " + " + at.getCA() + " est inferieur a "+def.getCD() +" donc l'attaque rate la cible");
        }




        return 0;
    }

    @Override
    public String name() {
        return null;
    }

    @Override
    public Class<? extends Annotation> annotationType() {
        return null;
    }
}
